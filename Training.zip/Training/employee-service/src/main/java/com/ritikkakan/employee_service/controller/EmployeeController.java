package com.ritikkakan.employee_service.controller;

import com.ritikkakan.employee_service.entity.Employee;
import com.ritikkakan.employee_service.payload.EmployeeDepartment;
import com.ritikkakan.employee_service.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("/api/employees")
@RestController
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;
    @GetMapping
    public ResponseEntity<List<Employee>> getAllEmployee(){
        var data = employeeService.getAllEmployee();
        return new ResponseEntity<>(data, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Employee> getEmployeeById(@PathVariable("id") int id){
        var data = employeeService.getEmployeeById(id);
        return new ResponseEntity<>(data,HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<Employee> createEmployee(@RequestBody Employee employee){
        var data = employeeService.createEmployee(employee);
        return new ResponseEntity<>(data,HttpStatus.CREATED);
    }

    @GetMapping("/{id}/department")
    public ResponseEntity<EmployeeDepartment> getEmployeeWithDepartment(@PathVariable("id") int id){
        var data = employeeService.getEmployeeWithDepartment(id);

        return new ResponseEntity<>(data,HttpStatus.OK);
    }
}
