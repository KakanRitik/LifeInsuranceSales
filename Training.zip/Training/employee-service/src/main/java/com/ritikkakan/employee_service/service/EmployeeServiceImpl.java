package com.ritikkakan.employee_service.service;

import com.ritikkakan.employee_service.entity.Employee;
import com.ritikkakan.employee_service.payload.Department;
import com.ritikkakan.employee_service.payload.EmployeeDepartment;
import com.ritikkakan.employee_service.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Service
public class EmployeeServiceImpl implements EmployeeService{

    @Autowired
    EmployeeRepository employeeRepository;

    @Autowired
    RestTemplate restTemplate;
    @Override
    public List<Employee> getAllEmployee() {
        return employeeRepository.findAll();
    }

    @Override
    public Employee getEmployeeById(int id) {
        return employeeRepository.findById(id).get();
    }

    @Override
    public Employee createEmployee(Employee employee) {
        return employeeRepository.save(employee);
    }

    @Override
    public EmployeeDepartment getEmployeeWithDepartment(int employeeId) {
      Employee employee = employeeRepository.findById(employeeId).get();

        Department department = restTemplate.getForObject("http://DEPARTMENT-SERVICE/api/departments/"+employee.getDepartmentId(),Department.class);

        EmployeeDepartment employeeDepartment =new EmployeeDepartment();
        employeeDepartment.setDepartment(department);
        employeeDepartment.setEmployee(employee);

        return employeeDepartment;
    }
}
